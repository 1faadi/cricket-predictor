// lib/chain.ts - Enhanced with smart PostgreSQL + Qdrant integration
import { config } from 'dotenv';
import { ChatGoogleGenerativeAI } from '@langchain/google-genai';
import { RunnableSequence } from '@langchain/core/runnables';
import { PromptTemplate } from '@langchain/core/prompts';
import { StringOutputParser } from '@langchain/core/output_parsers';
import { Pool } from 'pg';
import { QdrantClient } from '@qdrant/js-client-rest';
import { QdrantVectorStore } from '@langchain/community/vectorstores/qdrant';
import { TogetherAIEmbeddings } from '@langchain/community/embeddings/togetherai';

// Load environment variables
config();

// Database connection
const postgres = new Pool({
  connectionString: process.env.POSTGRES_URL,
  ssl: { rejectUnauthorized: false },
  max: 10,
  idleTimeoutMillis: 30000,
  connectionTimeoutMillis: 10000,
});

// Using Gemini
const llm = new ChatGoogleGenerativeAI({
  model: 'gemini-1.5-flash',
  apiKey: process.env.GOOGLE_API_KEY || process.env.GEMINI_API_KEY,
  temperature: 0.3,
  maxOutputTokens: 800,
});

// Embeddings for vector search
const embeddings = new TogetherAIEmbeddings({
  model: 'BAAI/bge-large-en-v1.5',
  apiKey: process.env.TOGETHERAI_API_KEY,
});

// Qdrant client
const qdrant = new QdrantClient({
  url: process.env.QDRANT_URL!,
  apiKey: process.env.QDRANT_API_KEY!,
});

// Initialize vector store
let vectorStore: QdrantVectorStore | null = null;

async function getVectorStore() {
  if (!vectorStore) {
    try {
      vectorStore = await QdrantVectorStore.fromExistingCollection(embeddings, {
        collectionName: 'match_summaries',
        client: qdrant,
      });
    } catch (error) {
      console.error('❌ Vector store initialization failed:', error);
      throw new Error('Failed to initialize vector store');
    }
  }
  return vectorStore;
}

// Query analysis to determine search strategy
export function analyzeQuery(question: string) {
  const lowerQuestion = question.toLowerCase();
  
  // Determine query type
  let type = 'general';
  if (lowerQuestion.includes('stat') || lowerQuestion.includes('average') || 
      lowerQuestion.includes('total') || lowerQuestion.includes('record')) {
    type = 'stats';
  } else if (lowerQuestion.includes('match') || lowerQuestion.includes('game') || 
             lowerQuestion.includes('final') || lowerQuestion.includes('report')) {
    type = 'match_report';
  } else if (lowerQuestion.includes('player') || lowerQuestion.includes('captain') ||
             lowerQuestion.includes('batsman') || lowerQuestion.includes('bowler')) {
    type = 'player_info';
  } else if (lowerQuestion.includes('team') || lowerQuestion.includes('vs') ||
             lowerQuestion.includes('against')) {
    type = 'team_info';
  } else if (lowerQuestion.includes('compare') || lowerQuestion.includes('better') ||
             lowerQuestion.includes('versus')) {
    type = 'comparison';
  }
  
  // Extract entities
  const entities = extractEntities(question);
  
  // Determine search strategy
  const searchStrategy = determineSearchStrategy(type, entities, question);
  
  return {
    type,
    entities,
    searchStrategy,
    needsVector: searchStrategy.includes('vector'),
    needsSQL: searchStrategy.includes('sql'),
    priority: type === 'stats' ? 'sql' : 'vector' // Stats queries prioritize SQL
  };
}

// Enhanced entity extraction
function extractEntities(question: string) {
  const entities: any = {
    teams: [],
    players: [],
    years: [],
    venues: [],
    matchTypes: []
  };
  
  const lowerQuestion = question.toLowerCase();
  
  // PSL teams with variations
  const teams = [
    { patterns: ['karachi kings', 'karachi', 'kings'], name: 'Karachi Kings' },
    { patterns: ['lahore qalandars', 'lahore', 'qalandars'], name: 'Lahore Qalandars' },
    { patterns: ['islamabad united', 'islamabad', 'united'], name: 'Islamabad United' },
    { patterns: ['peshawar zalmi', 'peshawar', 'zalmi'], name: 'Peshawar Zalmi' },
    { patterns: ['quetta gladiators', 'quetta', 'gladiators'], name: 'Quetta Gladiators' },
    { patterns: ['multan sultans', 'multan', 'sultans'], name: 'Multan Sultans' }
  ];
  
  teams.forEach(team => {
    if (team.patterns.some(pattern => lowerQuestion.includes(pattern))) {
      entities.teams.push(team.name);
    }
  });
  
  // Years and seasons
  const yearMatches = question.match(/\b(20\d{2})\b/g);
  if (yearMatches) {
    entities.years = yearMatches;
  }
  
  // PSL editions
  const editionMatch = lowerQuestion.match(/psl\s*(\d+)/i);
  if (editionMatch) {
    const year = 2015 + parseInt(editionMatch[1]);
    entities.years.push(year.toString());
  }
  
  // Common players (expand this list based on your database)
  const players = [
    'babar azam', 'mohammad rizwan', 'shaheen afridi', 'hassan ali',
    'fakhar zaman', 'mohammad hafeez', 'shoaib malik', 'kamran akmal',
    'shadab khan', 'wahab riaz', 'mohammad amir', 'sarfaraz ahmed'
  ];
  
  players.forEach(player => {
    if (lowerQuestion.includes(player)) {
      entities.players.push(player);
    }
  });
  
  // Match types
  const matchTypes = ['final', 'semifinal', 'qualifier', 'eliminator', 'playoff'];
  matchTypes.forEach(type => {
    if (lowerQuestion.includes(type)) {
      entities.matchTypes.push(type);
    }
  });
  
  return entities;
}

// Determine optimal search strategy
function determineSearchStrategy(type: string, entities: any, question: string): string[] {
  const strategies = [];
  
  // Always try vector search for semantic similarity
  strategies.push('vector');
  
  // Add SQL search based on query characteristics
  if (type === 'stats' || entities.teams.length > 0 || entities.players.length > 0 || entities.years.length > 0) {
    strategies.push('sql_specific');
  }
  
  // Add general SQL for broad queries
  if (type === 'general' || question.toLowerCase().includes('recent') || question.toLowerCase().includes('latest')) {
    strategies.push('sql_general');
  }
  
  return strategies;
}

// Enhanced context retrieval combining multiple sources
async function getEnhancedContext(input: { question: string; queryType?: string; entities?: any }): Promise<string> {
  const { question, queryType = 'general', entities = {} } = input;
  const analysis = analyzeQuery(question);
  
  console.log(`🔍 Processing ${analysis.type} query with strategy: ${analysis.searchStrategy.join(', ')}`);
  
  const contexts: any[] = [];
  const metadata: any = {
    sources: [],
    processingTime: {},
    resultCounts: {}
  };
  
  // 1. Vector Search (Semantic similarity)
  if (analysis.needsVector) {
    try {
      const vectorStart = Date.now();
      const store = await getVectorStore();
      const vectorResults = await store.similaritySearch(question, 4);
      
      if (vectorResults.length > 0) {
        const semanticContext = vectorResults.map((r, i) => ({
          type: 'match_summary',
          content: r.pageContent,
          relevance: i === 0 ? 'high' : i < 2 ? 'medium' : 'low'
        }));
        
        contexts.push({
          source: 'vector_search',
          title: 'Similar Matches Found',
          data: semanticContext
        });
        
        metadata.sources.push('qdrant');
        metadata.processingTime.vector = Date.now() - vectorStart;
        metadata.resultCounts.vector = vectorResults.length;
      }
    } catch (vectorError: unknown) {
      const errorMessage = vectorError instanceof Error ? vectorError.message : 'Unknown vector error';
      console.warn('⚠️ Vector search failed:', errorMessage);
      metadata.errors = metadata.errors || [];
      metadata.errors.push(`Vector search: ${errorMessage}`);
    }
  }
  
  // 2. Specific SQL Search (Based on entities)
  if (analysis.searchStrategy.includes('sql_specific')) {
    try {
      const sqlStart = Date.now();
      const sqlResults = await getSpecificSQLContext(analysis.entities, question);
      
      if (sqlResults.length > 0) {
        contexts.push({
          source: 'sql_specific',
          title: 'Specific Match Data',
          data: sqlResults
        });
        
        metadata.sources.push('postgres_specific');
        metadata.processingTime.sql_specific = Date.now() - sqlStart;
        metadata.resultCounts.sql_specific = sqlResults.length;
      }
    } catch (sqlError: unknown) {
      const errorMessage = sqlError instanceof Error ? sqlError.message : 'Unknown SQL error';
      console.warn('⚠️ Specific SQL search failed:', errorMessage);
    }
  }
  
  // 3. General SQL Search (Recent matches, general stats)
  if (analysis.searchStrategy.includes('sql_general')) {
    try {
      const generalStart = Date.now();
      const generalResults = await getGeneralSQLContext(question, analysis.type);
      
      if (generalResults.length > 0) {
        contexts.push({
          source: 'sql_general',
          title: 'General Cricket Data',
          data: generalResults
        });
        
        metadata.sources.push('postgres_general');
        metadata.processingTime.sql_general = Date.now() - generalStart;
        metadata.resultCounts.sql_general = generalResults.length;
      }
    } catch (generalError: unknown) {
      const errorMessage = generalError instanceof Error ? generalError.message : 'Unknown general SQL error';
      console.warn('⚠️ General SQL search failed:', errorMessage);
    }
  }
  
  // 4. Player-specific search if players mentioned
  if (analysis.entities.players.length > 0) {
    try {
      const playerStart = Date.now();
      const playerResults = await getPlayerSpecificContext(analysis.entities.players);
      
      if (playerResults.length > 0) {
        contexts.push({
          source: 'player_stats',
          title: 'Player Statistics',
          data: playerResults
        });
        
        metadata.sources.push('postgres_players');
        metadata.processingTime.player_stats = Date.now() - playerStart;
        metadata.resultCounts.player_stats = playerResults.length;
      }
    } catch (playerError: unknown) {
      const errorMessage = playerError instanceof Error ? playerError.message : 'Unknown player error';
      console.warn('⚠️ Player search failed:', errorMessage);
    }
  }
  
  // Combine and format contexts
  const combinedContext = formatCombinedContext(contexts, analysis);
  
  // Return just the context string for compatibility with existing chain structure
  return combinedContext;
}

// Get specific SQL context based on extracted entities
async function getSpecificSQLContext(entities: any, question: string): Promise<any[]> {
  let client;
  const results: any[] = [];
  
  try {
    client = await postgres.connect();
    
    // Team-specific queries
    if (entities.teams.length > 0) {
      for (const team of entities.teams) {
        const teamQuery = `
          SELECT 
            m.match_id, m.team1, m.team2, m.match_date, m.venue, m.winner,
            m.event_name, m.season, m.event_stage,
            i1.total_runs as team1_runs, i1.total_wickets as team1_wickets,
            i2.total_runs as team2_runs, i2.total_wickets as team2_wickets,
            m.player_of_match, m.toss_winner, m.toss_decision
          FROM matches m
          LEFT JOIN innings_summary i1 ON m.match_id = i1.match_id AND i1.innings_number = 1
          LEFT JOIN innings_summary i2 ON m.match_id = i2.match_id AND i2.innings_number = 2
          WHERE (LOWER(m.team1) = LOWER($1) OR LOWER(m.team2) = LOWER($1))
          ${entities.years.length > 0 ? 'AND EXTRACT(YEAR FROM m.match_date) = ANY($2)' : ''}
          ORDER BY m.match_date DESC
          LIMIT 5
        `;
        
        const queryParams = entities.years.length > 0 ? [team, entities.years] : [team];
        const result = await client.query(teamQuery, queryParams);
        
        results.push({
          type: 'team_matches',
          team: team,
          matches: result.rows
        });
      }
    }
    
    // Year-specific queries when no specific teams
    if (entities.years.length > 0 && entities.teams.length === 0) {
      const yearQuery = `
        SELECT 
          m.match_id, m.team1, m.team2, m.match_date, m.venue, m.winner,
          m.event_name, m.season, m.event_stage,
          i1.total_runs as team1_runs, i1.total_wickets as team1_wickets,
          i2.total_runs as team2_runs, i2.total_wickets as team2_wickets
        FROM matches m
        LEFT JOIN innings_summary i1 ON m.match_id = i1.match_id AND i1.innings_number = 1
        LEFT JOIN innings_summary i2 ON m.match_id = i2.match_id AND i2.innings_number = 2
        WHERE EXTRACT(YEAR FROM m.match_date) = ANY($1)
        ORDER BY m.match_date DESC
        LIMIT 8
      `;
      
      const result = await client.query(yearQuery, [entities.years]);
      results.push({
        type: 'year_matches',
        years: entities.years,
        matches: result.rows
      });
    }
    
    // Match type specific queries (finals, etc.)
    if (entities.matchTypes.length > 0) {
      const matchTypeQuery = `
        SELECT 
          m.match_id, m.team1, m.team2, m.match_date, m.venue, m.winner,
          m.event_name, m.season, m.event_stage,
          i1.total_runs as team1_runs, i1.total_wickets as team1_wickets,
          i2.total_runs as team2_runs, i2.total_wickets as team2_wickets,
          m.player_of_match
        FROM matches m
        LEFT JOIN innings_summary i1 ON m.match_id = i1.match_id AND i1.innings_number = 1
        LEFT JOIN innings_summary i2 ON m.match_id = i2.match_id AND i2.innings_number = 2
        WHERE LOWER(m.event_stage) = ANY($1)
        ORDER BY m.match_date DESC
        LIMIT 5
      `;
      
      const result = await client.query(matchTypeQuery, [entities.matchTypes.map((t: string) => t.toLowerCase())]);
      results.push({
        type: 'match_type',
        matchTypes: entities.matchTypes,
        matches: result.rows
      });
    }
    
  } catch (error: unknown) {
    const errorMessage = error instanceof Error ? error.message : 'Unknown SQL error';
    console.error('❌ Specific SQL context error:', errorMessage);
  } finally {
    if (client) client.release();
  }
  
  return results;
}

// Get general SQL context for broad queries
async function getGeneralSQLContext(question: string, queryType: string): Promise<any[]> {
  let client;
  const results: any[] = [];
  
  try {
    client = await postgres.connect();
    
    if (question.toLowerCase().includes('recent') || question.toLowerCase().includes('latest')) {
      // Recent matches
      const recentQuery = `
        SELECT 
          m.match_id, m.team1, m.team2, m.match_date, m.venue, m.winner,
          m.event_name, m.season,
          i1.total_runs as team1_runs, i1.total_wickets as team1_wickets,
          i2.total_runs as team2_runs, i2.total_wickets as team2_wickets
        FROM matches m
        LEFT JOIN innings_summary i1 ON m.match_id = i1.match_id AND i1.innings_number = 1
        LEFT JOIN innings_summary i2 ON m.match_id = i2.match_id AND i2.innings_number = 2
        WHERE m.match_date IS NOT NULL
        ORDER BY m.match_date DESC
        LIMIT 5
      `;
      
      const result = await client.query(recentQuery);
      results.push({
        type: 'recent_matches',
        matches: result.rows
      });
    }
    
    if (question.toLowerCase().includes('champion') || question.toLowerCase().includes('winner')) {
      // Championship data
      const championQuery = `
        SELECT 
          m.season, m.winner, m.event_stage, COUNT(*) as wins,
          STRING_AGG(DISTINCT m.venue, ', ') as venues
        FROM matches m
        WHERE m.winner IS NOT NULL 
        AND (LOWER(m.event_stage) LIKE '%final%' OR LOWER(m.event_stage) LIKE '%champion%')
        GROUP BY m.season, m.winner, m.event_stage
        ORDER BY m.season DESC
        LIMIT 10
      `;
      
      const result = await client.query(championQuery);
      results.push({
        type: 'championships',
        data: result.rows
      });
    }
    
  } catch (error: unknown) {
    const errorMessage = error instanceof Error ? error.message : 'Unknown general SQL error';
    console.error('❌ General SQL context error:', errorMessage);
  } finally {
    if (client) client.release();
  }
  
  return results;
}

// Get player-specific context
async function getPlayerSpecificContext(players: string[]): Promise<any[]> {
  let client;
  const results: any[] = [];
  
  try {
    client = await postgres.connect();
    
    for (const player of players) {
      // Player statistics
      const playerStatsQuery = `
        SELECT 
          ps.player_name, ps.team_name,
          COUNT(DISTINCT ps.match_id) as matches_played,
          SUM(ps.runs_scored) as total_runs,
          SUM(ps.balls_faced) as total_balls_faced,
          SUM(ps.wickets_taken) as total_wickets,
          ROUND(AVG(CASE WHEN ps.strike_rate > 0 THEN ps.strike_rate END), 1) as avg_strike_rate,
          ROUND(AVG(CASE WHEN ps.economy_rate > 0 THEN ps.economy_rate END), 2) as avg_economy_rate,
          SUM(ps.fours) as total_fours,
          SUM(ps.sixes) as total_sixes,
          MAX(ps.runs_scored) as highest_score
        FROM player_stats ps
        WHERE LOWER(ps.player_name) LIKE LOWER($1)
        GROUP BY ps.player_name, ps.team_name
        ORDER BY total_runs DESC
        LIMIT 3
      `;
      
      const statsResult = await client.query(playerStatsQuery, [`%${player}%`]);
      
      // Recent matches for this player
      const recentMatchesQuery = `
        SELECT DISTINCT
          m.match_id, m.team1, m.team2, m.match_date, m.winner,
          ts.team_name as player_team
        FROM matches m
        JOIN team_squads ts ON m.match_id = ts.match_id
        WHERE LOWER(ts.player_name) LIKE LOWER($1)
        ORDER BY m.match_date DESC
        LIMIT 5
      `;
      
      const matchesResult = await client.query(recentMatchesQuery, [`%${player}%`]);
      
      results.push({
        type: 'player_profile',
        player: player,
        stats: statsResult.rows,
        recentMatches: matchesResult.rows
      });
    }
    
  } catch (error: unknown) {
    const errorMessage = error instanceof Error ? error.message : 'Unknown player error';
    console.error('❌ Player context error:', errorMessage);
  } finally {
    if (client) client.release();
  }
  
  return results;
}

// Helper function to safely format numbers
function safeFormatNumber(value: any, decimals: number = 2): string {
  if (value === null || value === undefined || value === '') {
    return 'N/A';
  }
  
  const num = Number(value);
  if (isNaN(num)) {
    return 'N/A';
  }
  
  return num.toFixed(decimals);
}

// Format combined context for LLM consumption
function formatCombinedContext(contexts: any[], analysis: any): string {
  if (contexts.length === 0) {
    return 'No specific match data found in the database. Please provide general PSL information based on cricket knowledge.';
  }
  
  const sections: string[] = [];
  
  contexts.forEach(context => {
    switch (context.source) {
      case 'vector_search':
        sections.push(`=== SIMILAR MATCHES ===`);
        context.data.forEach((item: any, index: number) => {
          sections.push(`Match ${index + 1} (${item.relevance} relevance): ${item.content}`);
        });
        break;
        
      case 'sql_specific':
        sections.push(`=== SPECIFIC MATCH DATA ===`);
        context.data.forEach((dataset: any) => {
          if (dataset.type === 'team_matches') {
            sections.push(`\n--- ${dataset.team} Matches ---`);
            dataset.matches.forEach((match: any) => {
              const score1 = match.team1_runs !== null ? `${match.team1_runs}/${match.team1_wickets || 0}` : 'No score';
              const score2 = match.team2_runs !== null ? `${match.team2_runs}/${match.team2_wickets || 0}` : 'No score';
              sections.push(`${match.event_name} ${match.event_stage || ''}: ${match.team1} ${score1} vs ${match.team2} ${score2} on ${match.match_date} at ${match.venue}. Winner: ${match.winner || 'Unknown'}`);
              if (match.player_of_match && match.player_of_match.length > 0) {
                sections.push(`Player of Match: ${match.player_of_match.join(', ')}`);
              }
            });
          } else if (dataset.type === 'year_matches') {
            sections.push(`\n--- ${dataset.years.join(', ')} Season Matches ---`);
            dataset.matches.forEach((match: any) => {
              const score1 = match.team1_runs !== null ? `${match.team1_runs}/${match.team1_wickets || 0}` : 'No score';
              const score2 = match.team2_runs !== null ? `${match.team2_runs}/${match.team2_wickets || 0}` : 'No score';
              sections.push(`${match.event_name}: ${match.team1} ${score1} vs ${match.team2} ${score2} - Winner: ${match.winner || 'Unknown'}`);
            });
          } else if (dataset.type === 'match_type') {
            sections.push(`\n--- ${dataset.matchTypes.join(', ')} Matches ---`);
            dataset.matches.forEach((match: any) => {
              const score1 = match.team1_runs !== null ? `${match.team1_runs}/${match.team1_wickets || 0}` : 'No score';
              const score2 = match.team2_runs !== null ? `${match.team2_runs}/${match.team2_wickets || 0}` : 'No score';
              sections.push(`${match.event_name} ${match.event_stage}: ${match.team1} ${score1} vs ${match.team2} ${score2} on ${match.match_date}. Winner: ${match.winner}`);
              if (match.player_of_match && match.player_of_match.length > 0) {
                sections.push(`Player of Match: ${match.player_of_match.join(', ')}`);
              }
            });
          }
        });
        break;
        
      case 'sql_general':
        sections.push(`=== GENERAL CRICKET DATA ===`);
        context.data.forEach((dataset: any) => {
          if (dataset.type === 'recent_matches') {
            sections.push(`\n--- Recent PSL Matches ---`);
            dataset.matches.forEach((match: any) => {
              const score1 = match.team1_runs !== null ? `${match.team1_runs}/${match.team1_wickets || 0}` : 'No score';
              const score2 = match.team2_runs !== null ? `${match.team2_runs}/${match.team2_wickets || 0}` : 'No score';
              sections.push(`${match.team1} ${score1} vs ${match.team2} ${score2} on ${match.match_date} at ${match.venue}. Winner: ${match.winner || 'Unknown'}`);
            });
          } else if (dataset.type === 'championships') {
            sections.push(`\n--- Championship History ---`);
            dataset.data.forEach((champ: any) => {
              sections.push(`${champ.season}: ${champ.winner} (${champ.event_stage}, ${champ.wins} win(s)) at ${champ.venues}`);
            });
          }
        });
        break;
        
      case 'player_stats':
        sections.push(`=== PLAYER STATISTICS ===`);
        context.data.forEach((playerData: any) => {
          sections.push(`\n--- ${playerData.player} Profile ---`);
          playerData.stats.forEach((stat: any) => {
            sections.push(`Team: ${stat.team_name || 'Unknown'}`);
            sections.push(`Matches: ${stat.matches_played || 0}, Runs: ${stat.total_runs || 0}, Strike Rate: ${safeFormatNumber(stat.avg_strike_rate, 1)}`);
            sections.push(`Wickets: ${stat.total_wickets || 0}, Economy: ${safeFormatNumber(stat.avg_economy_rate, 2)}`);
            sections.push(`Boundaries: ${stat.total_fours || 0} fours, ${stat.total_sixes || 0} sixes`);
            if (stat.highest_score) {
              sections.push(`Highest Score: ${stat.highest_score}`);
            }
          });
          
          if (playerData.recentMatches && playerData.recentMatches.length > 0) {
            sections.push(`Recent matches:`);
            playerData.recentMatches.forEach((match: any) => {
              sections.push(`${match.team1} vs ${match.team2} on ${match.match_date} (${match.player_team}) - Winner: ${match.winner || 'Unknown'}`);
            });
          }
        });
        break;
    }
    sections.push(''); // Add spacing between sections
  });
  
  return sections.join('\n');
}

// Simplified chain for compatibility
export function getChain() {
  const template = PromptTemplate.fromTemplate(`
You are a comprehensive PSL cricket expert with access to detailed match databases.

CONTEXT: {context}
QUESTION: {question}

Based on the provided database context, give an informative and engaging response about PSL cricket.

Guidelines:
- Use specific data from the context when available
- Be conversational and engaging for cricket fans
- Format statistics clearly and comparatively
- Tell match stories with key moments and context
- If context is limited, acknowledge it but still provide helpful information
- Stay focused on PSL cricket topics

Response:`);

  const chain = RunnableSequence.from([
    {
      question: (input: { question: string }) => input.question,
      context: async (input: { question: string }) => {
        const result = await getEnhancedContext(input);
        return result;
      },
    },
    template,
    llm,
    new StringOutputParser(),
  ]);

  return chain;
}

// Enhanced health check with database statistics
export async function healthCheck() {
  const checks = {
    postgres: false,
    qdrant: false,
    gemini: false,
    embeddings: false,
    stats: {},
    responseTime: 0
  };

  const startTime = Date.now();

  // Test Postgres with stats
  try {
    const client = await postgres.connect();
    
    // Basic connection test
    await client.query('SELECT 1');
    checks.postgres = true;
    
    // Get database statistics
    const statsQuery = `
      SELECT 
        (SELECT COUNT(*) FROM matches) as total_matches,
        (SELECT COUNT(*) FROM team_squads) as total_player_records,
        (SELECT COUNT(*) FROM innings_summary) as total_innings,
        (SELECT COUNT(DISTINCT player_name) FROM player_stats) as unique_players,
        (SELECT MAX(match_date) FROM matches WHERE match_date IS NOT NULL) as latest_match,
        (SELECT MIN(match_date) FROM matches WHERE match_date IS NOT NULL) as earliest_match
    `;
    
    const statsResult = await client.query(statsQuery);
    checks.stats = statsResult.rows[0];
    
    client.release();
  } catch (error: unknown) {
    const errorMessage = error instanceof Error ? error.message : 'Unknown error';
    console.error('❌ Postgres health check failed:', errorMessage);
  }

  // Test Qdrant
  try {
    const collections = await qdrant.getCollections();
    checks.qdrant = true;
    
    // Get collection info
    try {
      const collectionInfo = await qdrant.getCollection('match_summaries');
      (checks.stats as any).vector_count = collectionInfo.points_count;
    } catch (e) {
      // Collection might not exist yet
      (checks.stats as any).vector_count = 0;
    }
  } catch (error: unknown) {
    const errorMessage = error instanceof Error ? error.message : 'Unknown error';
    console.error('❌ Qdrant health check failed:', errorMessage);
  }

  // Test Gemini
  try {
    await llm.invoke('Test connection');
    checks.gemini = true;
  } catch (error: unknown) {
    const errorMessage = error instanceof Error ? error.message : 'Unknown error';
    console.error('❌ Gemini health check failed:', errorMessage);
  }

  // Test embeddings
  try {
    await embeddings.embedQuery('test');
    checks.embeddings = true;
  } catch (error: unknown) {
    const errorMessage = error instanceof Error ? error.message : 'Unknown error';
    console.error('❌ Embeddings health check failed:', errorMessage);
  }

  checks.responseTime = Date.now() - startTime;
  return checks;
}

// Export for testing and direct usage
export async function testChain(question: string) {
  try {
    const chain = getChain();
    const result = await chain.invoke({ question });
    return result;
  } catch (error: unknown) {
    const errorMessage = error instanceof Error ? error.message : 'Unknown error';
    console.error('❌ Chain test error:', errorMessage);
    throw error;
  }
}

// Direct context testing
export async function testContext(question: string) {
  try {
    const result = await getEnhancedContext({ question });
    return {
      context: result,
      metadata: { sources: ['combined'], message: 'Simplified response for compatibility' }
    };
  } catch (error: unknown) {
    const errorMessage = error instanceof Error ? error.message : 'Unknown error';
    console.error('❌ Context test error:', errorMessage);
    throw error;
  }
}

// Utility function for getting player statistics
export async function getPlayerStats(playerName: string) {
  let client;
  try {
    client = await postgres.connect();
    
    const playerQuery = `
      SELECT 
        ps.player_name, ps.team_name,
        COUNT(DISTINCT ps.match_id) as matches_played,
        SUM(ps.runs_scored) as total_runs,
        SUM(ps.balls_faced) as total_balls_faced,
        SUM(ps.wickets_taken) as total_wickets,
        ROUND(AVG(CASE WHEN ps.strike_rate > 0 THEN ps.strike_rate END), 1) as avg_strike_rate,
        ROUND(AVG(CASE WHEN ps.economy_rate > 0 THEN ps.economy_rate END), 2) as avg_economy_rate,
        SUM(ps.fours) as total_fours,
        SUM(ps.sixes) as total_sixes,
        MAX(ps.runs_scored) as highest_score
      FROM player_stats ps
      WHERE LOWER(ps.player_name) LIKE LOWER($1)
      GROUP BY ps.player_name, ps.team_name
      ORDER BY total_runs DESC
      LIMIT 5
    `;
    
    const result = await client.query(playerQuery, [`%${playerName}%`]);
    return result.rows;
    
  } catch (error: unknown) {
    const errorMessage = error instanceof Error ? error.message : 'Unknown error';
    console.error('❌ Player stats error:', errorMessage);
    return [];
  } finally {
    if (client) client.release();
  }
}

export { getEnhancedContext, postgres };