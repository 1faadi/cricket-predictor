// app/api/chat/route.ts - Enhanced with smart context handling
import { streamText } from 'ai';
import { createGoogleGenerativeAI } from '@ai-sdk/google';
import { getChain, analyzeQuery, healthCheck } from '@/lib/chain';
import { CoreMessage } from 'ai';

// Initialize Gemini
const google = createGoogleGenerativeAI({
  apiKey: process.env.GEMINI_API_KEY,
});

export async function POST(req: Request) {
  try {
    console.log('🚀 Chat API called with Gemini');

    const body = await req.json();
    const { messages }: { messages: CoreMessage[] } = body;

    if (!messages || messages.length === 0) {
      return new Response(
        JSON.stringify({ error: 'No messages provided' }),
        { status: 400, headers: { 'Content-Type': 'application/json' } }
      );
    }

    const userMessage = messages[messages.length - 1];
    const input = typeof userMessage.content === 'string' ? userMessage.content : '';

    if (!input.trim()) {
      return new Response(
        JSON.stringify({ error: 'Empty message content' }),
        { status: 400, headers: { 'Content-Type': 'application/json' } }
      );
    }

    console.log('📝 User question:', input);

    // Analyze the query to understand what type of response is needed
    const queryAnalysis = analyzeQuery(input);
    console.log('🔍 Query analysis:', queryAnalysis);

    // Get enhanced context from chain (combines vector + SQL search)
    const chain = getChain();
    let chainResult: string;
    let contextMetadata: any = {};

    try {
      const startTime = Date.now();
      const result = await chain.invoke({ question: input });
      if (!result || result.includes("No specific match data found")) {
  return new Response(
    JSON.stringify({
      type: "info",
      message: "I don’t have that specific record in the current PSL database.",
    }),
    { status: 200, headers: { "Content-Type": "application/json" } }
  );
}
      
      const processingTime = Date.now() - startTime;
      console.log(`⚡ Chain processing completed in ${processingTime}ms`);
      
      // Handle both string and object responses
      if (typeof result === 'string') {
        chainResult = result;
      } else if (result && typeof result === 'object') {
        // Try to extract context and metadata if available
        chainResult = (result as any).context || (result as any).content || String(result);
        contextMetadata = (result as any).metadata || {};
      } else {
        chainResult = String(result);
      }
      
      console.log('🔗 Chain result length:', chainResult?.length || 0);
      console.log('📊 Context metadata:', contextMetadata);
      
    } catch (chainError) {
      console.error('❌ Chain error:', chainError);
      chainResult = 'I apologize, but I encountered an issue accessing the cricket database. I can still help with general PSL questions based on my knowledge.';
      contextMetadata = { error: true, fallback: true };
    }

    // Create context-aware system message based on query type and available data
    const systemMessage = createSystemMessage(input, chainResult, queryAnalysis, contextMetadata);

    const result = await streamText({
      model: google('gemini-1.5-flash'),
      messages: [systemMessage, userMessage],
      temperature: queryAnalysis.type === 'stats' ? 0.3 : 0.7, // Lower temp for stats, higher for stories
      maxTokens: 1000,
    });

    return result.toDataStreamResponse();
    
  } catch (error) {
    console.error('❌ Chat API error:', error);
    return new Response(
      JSON.stringify({
        error: 'Failed to process chat request',
        details: error instanceof Error ? error.message : 'Unknown error',
      }),
      { status: 500, headers: { 'Content-Type': 'application/json' } }
    );
  }
}

// Smart system message creation based on query type and context
function createSystemMessage(
  userQuestion: string, 
  context: string, 
  queryAnalysis: any, 
  metadata: any
): CoreMessage {
  
  let basePrompt = `You are an expert PSL (Pakistan Super League) cricket assistant with access to comprehensive match data, player statistics, and historical records.`;
  
  // Add context information
  if (context && !metadata.error) {
    basePrompt += `\n\nDATABASE CONTEXT:\n${context}`;
  }
  
  // Add specific instructions based on query type
  switch (queryAnalysis.type) {
    case 'stats':
      basePrompt += `\n\nThis is a STATISTICS query. Please:
- Present numbers clearly with bullet points or tables
- Include comparative context when possible
- Mention the time period or season if relevant
- Be precise and factual
- If specific stats aren't available, explain what data you do have`;
      break;
      
    case 'match_report':
      basePrompt += `\n\nThis is a MATCH REPORT query. Please:
- Tell the story engagingly with key moments
- Include match context (venue, date, significance)
- Highlight standout performances
- Describe the match flow and turning points
- Make it narrative and exciting`;
      break;
      
    case 'player_info':
      basePrompt += `\n\nThis is a PLAYER INFORMATION query. Please:
- Provide comprehensive player profile
- Include recent performance data
- Mention team associations and role
- Add interesting achievements or records
- Be informative yet engaging`;
      break;
      
    case 'team_info':
      basePrompt += `\n\nThis is a TEAM INFORMATION query. Please:
- Cover team history and achievements
- Include recent performance and key players
- Mention home ground and fan base
- Add interesting team facts
- Be comprehensive yet engaging`;
      break;
      
    case 'comparison':
      basePrompt += `\n\nThis is a COMPARISON query. Please:
- Present clear head-to-head comparisons
- Use tables or structured format when helpful
- Highlight key differences and similarities
- Provide context for the comparison
- Be balanced and objective`;
      break;
      
    default:
      basePrompt += `\n\nThis is a GENERAL cricket query. Please:
- Be conversational and helpful
- Use the database context to provide accurate information
- If the context is limited, acknowledge it but still try to help
- Stay focused on PSL cricket topics`;
  }
  
  // Add general guidelines
  basePrompt += `\n\nGENERAL GUIDELINES:
- You MUST answer using ONLY the DATABASE CONTEXT above.
- If the DATABASE CONTEXT does not contain the exact data required, reply:
  "The database does not contain that specific information."
- Do NOT use any external knowledge or assumptions.
- Use engaging, conversational tone appropriate for cricket fans
- Include relevant details like dates, venues, scores when available
- Keep responses informative but not overwhelming`;
  
  // Handle error states
  if (metadata.error) {
    basePrompt += `\n\nNOTE: Database access is currently limited. Provide the best help possible with general PSL knowledge while acknowledging the limitation.`;
  }
  
  return {
    role: 'system',
    content: basePrompt
  };
}

// Enhanced health check with detailed service status
export async function GET() {
  try {
    const healthStatus = await healthCheck();
    
    return new Response(
      JSON.stringify({
        status: 'healthy',
        timestamp: new Date().toISOString(),
        services: {
          gemini: !!process.env.GEMINI_API_KEY,
          postgres: healthStatus.postgres,
          qdrant: healthStatus.qdrant,
          embeddings: healthStatus.embeddings,
        },
        database_stats: healthStatus.stats || {},
        response_time: healthStatus.responseTime || 0
      }),
      { 
        status: 200, 
        headers: { 
          'Content-Type': 'application/json',
          'Cache-Control': 'no-cache, no-store, must-revalidate'
        } 
      }
    );
  } catch (error) {
    console.error('❌ Health check error:', error);
    return new Response(
      JSON.stringify({
        status: 'degraded',
        timestamp: new Date().toISOString(),
        error: error instanceof Error ? error.message : 'Unknown error',
        services: {
          gemini: !!process.env.GEMINI_API_KEY,
          postgres: false,
          qdrant: false,
          embeddings: false,
        }
      }),
      { 
        status: 503,
        headers: { 'Content-Type': 'application/json' }
      }
    );
  }
}